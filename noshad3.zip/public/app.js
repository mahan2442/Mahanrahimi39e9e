// Nooshad UI interactions: accessible menus and safe form feedback.
(function(){
  const body=document.body;
  function setExpanded(button,value){if(button)button.setAttribute('aria-expanded',String(value));}
  function closeSiteMenu(header){header.classList.remove('menu-open','menu-collapsed');const b=header.querySelector('.hamb');setExpanded(b,false);}
  document.addEventListener('click',function(e){
    const siteButton=e.target.closest('.site-header .hamb');
    if(siteButton){
      e.preventDefault();const header=siteButton.closest('.site-header');
      if(window.matchMedia('(max-width: 900px)').matches){const open=header.classList.toggle('menu-open');setExpanded(siteButton,open);}
      else{const collapsed=header.classList.toggle('menu-collapsed');setExpanded(siteButton,!collapsed);}
      return;
    }
    const appButton=e.target.closest('.app-body .app-top .hamb');
    if(appButton){e.preventDefault();const open=body.classList.toggle('nav-open');setExpanded(appButton,open);return;}
    if(e.target.closest('.sidebar-close')||e.target.classList.contains('app-backdrop')){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);return;}
    const siteLink=e.target.closest('.site-header nav a');
    if(siteLink){closeSiteMenu(siteLink.closest('.site-header'));}
    const appLink=e.target.closest('.sidebar nav a');
    if(appLink&&window.innerWidth<=900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);document.querySelectorAll('.site-header').forEach(closeSiteMenu);}});
  window.addEventListener('resize',function(){if(window.innerWidth>900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);const h=document.querySelector('.site-header');if(h){h.classList.remove('menu-open');}}else{document.querySelectorAll('.site-header').forEach(h=>h.classList.remove('menu-collapsed'));}});
  document.querySelectorAll('form').forEach(function(form){form.addEventListener('submit',function(){if(!form.checkValidity())return;const button=form.querySelector('button[type="submit"],button:not([type])');if(button&&!button.dataset.busy){button.dataset.busy='1';button.dataset.oldText=button.textContent;button.textContent='در حال ثبت…';button.setAttribute('aria-busy','true');}});});
  const userRole=document.querySelector('form[action="/users"] select[name="role"]');
  if(userRole){const userForm=userRole.form;const phone=userForm.querySelector('[name="phone"]');const guardian=userForm.querySelector('[name="guardian_phone"]');function syncStudentFields(){const isStudent=userRole.value==='student';if(phone)phone.required=isStudent;if(guardian)guardian.required=isStudent;}userRole.addEventListener('change',syncStudentFields);syncStudentFields();}
  // Online exam builder, draggable answer sheet, timer and answer autosave.
  const examForm=document.getElementById('exam-create-form');
  if(examForm){
    const holder=document.getElementById('typed-questions'),jsonInput=document.getElementById('questions-json');let qid=0;
    function addQuestion(){qid++;const box=document.createElement('div');box.className='panel exam-builder-question';box.innerHTML=`<h4>سؤال ${qid}</h4><textarea class="q-text" rows="2" placeholder="متن سؤال را بنویسید" required></textarea><div class="q-options">${[1,2,3,4].map((n)=>`<label>گزینه ${n}<input class="q-option" required placeholder="گزینه ${n}"></label>`).join('')}</div><label>گزینه صحیح<select class="q-correct">${[1,2,3,4].map((n)=>`<option value="${n-1}">گزینه ${n}</option>`).join('')}</select></label><button type="button" class="small-btn danger remove-q">حذف سؤال</button>`;holder.appendChild(box);box.querySelector('.remove-q').onclick=()=>{box.remove();renumber();};}
    function renumber(){qid=0;holder.querySelectorAll('.exam-builder-question').forEach(b=>{qid++;b.querySelector('h4').textContent='سؤال '+qid;});}
    document.getElementById('add-exam-question')?.addEventListener('click',addQuestion);addQuestion();
    examForm.addEventListener('submit',e=>{const mode=document.getElementById('exam-mode').value;if(mode==='typed'){const qs=[...holder.querySelectorAll('.exam-builder-question')].map(b=>({text:b.querySelector('.q-text').value.trim(),options:[...b.querySelectorAll('.q-option')].map(x=>x.value.trim()),correct:Number(b.querySelector('.q-correct').value)}));if(!qs.length||qs.some(q=>!q.text||q.options.some(x=>!x))){e.preventDefault();alert('لطفاً متن تمام سؤال‌ها و گزینه‌ها را کامل کنید.');return;}jsonInput.value=JSON.stringify(qs);} });
    const mode=document.getElementById('exam-mode'),typed=document.getElementById('typed-builder');const imageBuilder=document.getElementById('image-answer-builder'),countInput=document.getElementById('image-question-count'),imageRows=document.getElementById('image-answer-rows');function rebuildImageKey(){if(!imageRows||!countInput)return;const n=Math.max(1,Math.min(200,Number(countInput.value)||1));const prior=[...imageRows.querySelectorAll('select')].map(x=>x.value);imageRows.innerHTML=Array.from({length:n},(_,i)=>`<label class="image-key-row">سؤال ${i+1}<select><option value="0">A</option><option value="1">B</option><option value="2">C</option><option value="3">D</option></select></label>`).join('');imageRows.querySelectorAll('select').forEach((x,i)=>{if(prior[i]!==undefined)x.value=prior[i];});}function syncExamMode(){const isImage=mode.value==='image';typed.hidden=isImage;if(imageBuilder)imageBuilder.hidden=!isImage;typed.querySelectorAll('input,textarea,select').forEach(el=>{if(el.classList.contains('q-text')||el.classList.contains('q-option'))el.required=!isImage;});if(isImage)rebuildImageKey();}mode.addEventListener('change',syncExamMode);countInput?.addEventListener('change',rebuildImageKey);examForm.addEventListener('submit',e=>{if(mode.value==='image'){const keys=[...imageRows.querySelectorAll('select')].map(x=>Number(x.value));document.getElementById('image-answers-json').value=JSON.stringify(keys);} });syncExamMode();
  }
  const examTimer=document.querySelector('.exam-timer');
  if(examTimer){let remaining=Number(examTimer.dataset.remaining);const total=Number(examTimer.dataset.duration);const ring=examTimer.querySelector('.timer-progress'),circ=2*Math.PI*52;ring.style.strokeDasharray=String(circ);function tick(){const mm=Math.floor(remaining/60),ss=remaining%60,hh=Math.floor(mm/60);document.getElementById('timer-text').textContent=hh?`${String(hh).padStart(2,'0')}:${String(mm%60).padStart(2,'0')}:${String(ss).padStart(2,'0')}`:`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;ring.style.strokeDashoffset=String(circ*(1-Math.max(0,remaining)/total));if(remaining<=0){document.getElementById('exam-submit')?.requestSubmit();return;}remaining--;setTimeout(tick,1000);}tick();
    const examId=location.pathname.match(/online-exams\/(\d+)/)?.[1];const csrf=document.querySelector('#exam-submit input[name="_csrf"]')?.value;let busy=false;
    async function answer(q,a,button){const siblings=document.querySelectorAll(`[data-q="${q}"]`);const selected=button.classList.contains('chosen');siblings.forEach(b=>b.classList.remove('chosen'));if(!selected)button.classList.add('chosen');const value=selected?-1:a;try{const r=await fetch(`/online-exams/${examId}/answer`,{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'fetch'},body:JSON.stringify({question_no:Number(q),answer_index:value,_csrf:csrf})});if(!r.ok){if(r.status===410)document.getElementById('exam-submit')?.requestSubmit();}}catch(e){button.classList.toggle('unsynced',!selected);}}
    document.querySelectorAll('.exam-option,.answer-dot').forEach(b=>b.addEventListener('click',()=>answer(b.dataset.q,b.dataset.a,b)));
    function logEvent(t){if(!examId)return;const body=JSON.stringify({event_type:t});if(navigator.sendBeacon){const blob=new Blob([body],{type:'application/json'});navigator.sendBeacon(`/online-exams/${examId}/event`,blob);}else fetch(`/online-exams/${examId}/event`,{method:'POST',headers:{'Content-Type':'application/json'},body,keepalive:true}).catch(()=>{});}
    document.addEventListener('visibilitychange',()=>{if(document.hidden)logEvent('visibility_hidden');});window.addEventListener('pagehide',()=>logEvent('page_exit'));
    const sheet=document.getElementById('answer-sheet'),handle=sheet?.querySelector('.answer-sheet-handle');if(handle){let startY=0,startH=0;handle.addEventListener('pointerdown',e=>{startY=e.clientY;startH=sheet.offsetHeight;handle.setPointerCapture(e.pointerId);});handle.addEventListener('pointermove',e=>{if(!handle.hasPointerCapture(e.pointerId))return;sheet.style.height=Math.max(150,Math.min(window.innerHeight*.72,startH+startY-e.clientY))+'px';});handle.addEventListener('pointerup',e=>{if(handle.hasPointerCapture(e.pointerId))handle.releasePointerCapture(e.pointerId);});}
  }
  const resourceTarget=document.getElementById('resource-target');if(resourceTarget){const sync=()=>{const grade=resourceTarget.value==='grade';document.getElementById('resource-grade').hidden=!grade;document.getElementById('resource-class').hidden=grade;};resourceTarget.addEventListener('change',sync);sync();}
  // Three-slide homepage carousel. The original school photo stays as the hero background;
  // only the heading and supporting text rotate, so the design and image composition remain intact.
  const carousel=document.querySelector('[data-carousel]');
  if(carousel){
    const slides=[
      {eyebrow:'دانش، اندیشه، آینده',title:document.querySelector('[data-slide-title]')?.textContent||'مدرسه نوشاد',text:'محیطی برای یادگیری، پرورش استعدادها، تجربه‌های تازه و ساختن آینده‌ای روشن؛ همراه دانش‌آموزان در مسیر رشد علمی و شخصیتی.'},
      {eyebrow:'مسیر رشد و شکوفایی',title:'هر دانش‌آموز، یک استعداد ارزشمند',text:'با تکیه بر آموزش عمیق، پرسشگری و خلاقیت، زمینه رشد علمی و فردی دانش‌آموزان را فراهم می‌کنیم.'},
      {eyebrow:'افتخار به تلاش و یادگیری',title:'آینده را با دانش می‌سازیم',text:'همراهی خانواده‌ها و کادر آموزشی، مدرسه را به فضایی برای تجربه، مسئولیت‌پذیری و موفقیت تبدیل می‌کند.'}
    ];
    let current=0;const title=carousel.querySelector('[data-slide-title]'),eyebrow=carousel.querySelector('[data-slide-eyebrow]'),copy=carousel.querySelector('.carousel-copy'),desc=carousel.querySelector('[data-slide-text]'),dots=Array.from(carousel.querySelectorAll('[data-slide]'));
    function show(i){current=(i+slides.length)%slides.length;const d=slides[current];if(copy){copy.style.animation='none';void copy.offsetWidth;copy.style.animation='';}if(title)title.textContent=d.title;if(eyebrow)eyebrow.textContent=d.eyebrow;if(desc)desc.textContent=d.text;dots.forEach((b,j)=>{b.classList.toggle('active',j===current);b.setAttribute('aria-pressed',String(j===current));});}
    dots.forEach((b)=>b.addEventListener('click',()=>show(Number(b.dataset.slide))));
    carousel.querySelector('[data-prev-slide]')?.addEventListener('click',()=>show(current-1));
    carousel.querySelector('[data-next-slide]')?.addEventListener('click',()=>show(current+1));
    let timer=setInterval(()=>show(current+1),6500);carousel.addEventListener('mouseenter',()=>clearInterval(timer));carousel.addEventListener('mouseleave',()=>{clearInterval(timer);timer=setInterval(()=>show(current+1),6500);});
  }
})();
